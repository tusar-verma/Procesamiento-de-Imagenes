> No se aprecia una diferencia sustancial en la segunda eq.
